ok = true

//
//  -----------------------------------------
//  If only spaces were entered make it null
//  ----------------------------------------
//
function CheckNull(field){
    spcchr=0
    for(i=0;i<field.length;i++) {
        if (field.charAt(i)==" ") 
            spcchr++
    }    
    if (spcchr==field.length) {
        return ""
    }
    else
        return field
}

//
//  -------------------------------------------------
//  Check for invalid characters in the numeric field
//  -------------------------------------------------
// 
function CheckNum(NumField) {
    if(NumField == ""){
        ok = false
        return ok
    }
    nums="0123456789:"
    for(i=0;i<nums.length;i++) {
        if (nums.indexOf(NumField.charAt(i))==-1){
            ok = false
            return ok
        }
    }
	return true ; 
}

//
//  -----------------------------------------
//  Check for numbers in the character field.
//  -----------------------------------------
//
function CheckAlpha(ChrField) {
      alpha="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz. " 
      for(i=0;i<alpha.length;i++) {
        if (alpha.indexOf(ChrField.charAt(i))==-1) {
            ok=false
        return ok
        }
     }  

}
//
//  -----------------------------------------
//  Email Validation
//  -----------------------------------------
//

function ValidateEmail(vEmail) {    
   if (vEmail.indexOf('@',0)==-1 ||
       vEmail.indexOf('@',0)== 0 ||
       vEmail.indexOf('.',0)==-1 ||
       vEmail.indexOf("'",0) > -1)
    	return false ;
   else
    return true
    
 }
 //
//  -----------------------------------------
//  Getting / Setting values from / to Radio Buttons
//		If no button is selectedm returns false...
//	    Else returns the selected value...		
//  -----------------------------------------
//

function getSetRadio(obj) { // P2 is optional and implies we are Setting
	for (var i=0; i < obj.length; i++) {
		if (arguments.length > 1) { // we are setting
			if (arguments[1] == null) {
				obj[i].checked = false;
			} else
			if (obj[i].value == arguments[1]) {
				obj[i].checked = true;
				return true;
			}
		} else { // we are getting
			if (obj[i].checked) 
				return obj[i].value;
		}
	}
	return false;
}

//----- Call this function like
//	var corAns = getSetRadio(document.PollForm.rb_ans);
//	if (!corAns) 
//		alert("Please Mark the Correct Answer...");
//	else
//		alert("You selected "+corAns) ;
//	return true ;

//  -----------------------------------------  End of this Radio Button   ------------------------------

//  -----------------------------------------  Start of this Radio Button   ------------------------------
function getSelectedCheckbox(buttonGroup) {
   // Go through all the check boxes. return an array of all the ones
   // that are selected (their position numbers). if no boxes were checked,
   // returned array will be empty (length will be zero)
   var retArr = new Array();
   var lastElement = 0;
   if (buttonGroup[0]) { // if the button group is an array (one check box is not an array)
      for (var i=0; i<buttonGroup.length; i++) {
         if (buttonGroup[i].checked) {
            retArr.length = lastElement;
            retArr[lastElement] = i;
            lastElement++;
         }
      }
   } else { // There is only one check box (it's not an array)
      if (buttonGroup.checked) { // if the one check box is checked
         retArr.length = lastElement;
         retArr[lastElement] = 0; // return zero as the only array value
      }
   }
   return retArr;
} // Ends the "getSelectedCheckbox" function

function getSelectedCheckboxValue(buttonGroup) {
   // return an array of values selected in the check box group. if no boxes
   // were checked, returned array will be empty (length will be zero)
   var retArr = new Array(); // set up empty array for the return values
   var selectedItems = getSelectedCheckbox(buttonGroup);
   if (selectedItems.length != 0) { // if there was something selected
      retArr.length = selectedItems.length;
      for (var i=0; i<selectedItems.length; i++) {
         if (buttonGroup[selectedItems[i]]) { // Make sure it's an array
            retArr[i] = buttonGroup[selectedItems[i]].value;
         } else { // It's not an array (there's just one check box and it's selected)
            retArr[i] = buttonGroup.value;// return that value
         }
      }
   }
   return retArr;
} // Ends the "getSelectedCheckBoxValue" function

//  -----------------------------------------  End of this Check Box   ------------------------------
